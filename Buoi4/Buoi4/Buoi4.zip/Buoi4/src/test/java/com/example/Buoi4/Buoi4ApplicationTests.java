package com.example.Buoi4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Buoi4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
